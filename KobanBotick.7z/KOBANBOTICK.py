import telebot
import random
bot = telebot.TeleBot("6029189941:AAEDGvHB_KVfKC1rb2EUNpbFrUgIgaGnUsg")
@bot.message_handler(commands=["start"])
def start(m, res=False):
 bot.send_message(m.chat.id,"What you know about")
 @bot.message_handler(content_types=["text"])
 def handle_text(message):
     bot.send_message(message.chat.id, 'Вы написали: ' + message)
 bot.polling(none_stop=True, interval=0)
bot = telebot.TeleBot("6029189941:AAEDGvHB_KVfKC1rb2EUNpbFrUgIgaGnUsg")
films=['Убить Билла','Интелстеллар','Марсианин','Легенда','Эффект бабочки','Омерзительная восьмерка']
filmsreturn=[]
for item in films:
    filmsreturn.append(item)
str=''
item=''
@bot.message_handler(commands=["commands"])
def start(m, res=False):
    bot.send_message(m.chat.id, 'Нажмите 1 чтобы зарандомить:\nНажмите 2 чтобы добавить элемент:\nНажмите 3 '
                                'чтобы удалить элемент:')
@bot.message_handler(content_types=["text"])
def handle_text(message):
    if message.text == '1':
        bot.send_message(message.chat.id, 'Я зарандомил: ' + RandomElement())
    if message.text == '2':
        bot.send_message(message.chat.id, 'Напишите фильм ')
        bot.register_next_step_handler(message,AddElement)
    if message.text == '3':
        bot.send_message(message.chat.id, 'Напишите фильм, который надо удалить')
        bot.register_next_step_handler(message, RemoveElement)
def RandomElement():
    if len(filmsreturn)!=0:
        index = random.randint(0, len(filmsreturn) - 1)
        str = filmsreturn[index]
        filmsreturn.remove(filmsreturn[index])
        return str
    else:
        for item in films:
            filmsreturn.append(item)
        index = random.randint(0, len(filmsreturn) - 1)
        str = filmsreturn[index]
        filmsreturn.remove(filmsreturn[index])
        return str
def AddElement(message):
    global item
    item=message.text
    if not films.contains(item):
        films.append(item)
        filmsreturn.append(item)
        bot.send_message(message.from_user.id, f'Добавил фильм {message.text}');
    else:
        bot.send_message(message.chat.id, f'фильм {message.text} существует, напишите новый')
        bot.register_next_step_handler(message,AddElement)
def RemoveElement(message):
    global item
    item = message.text
    if films.contains(item):
        films.remove(item)
        filmsreturn.remove(item)
        bot.send_message(message.from_user.id, f'Удалил фильм {message.text}');
    else:
        bot.send_message(message.from_user.id, f'Фильма не существует в списке, хотите добавлю?(Скажите да)');
        bot.register_next_step_handler(message, AddElement)
bot.polling(none_stop=True, interval=0)