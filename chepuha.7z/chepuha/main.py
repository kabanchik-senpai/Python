# def print_person(name,age):
#     print(f"name: {name}")
#     print(f"age: {age}")
#
#
# print_person("Thomas", 44)

# def print_person(name, age=336):
#     print(f"Name:{name} Age: {age}")
#
# print_person("Bib")
# Print_person("Nigga",228)

# def sum(*numbers):
#     result = 0
#     for n in numbers:
#         result += n
#     print(f"sum = {result}")
#
#
# sum(1,2,3,4,5,6,7,8,9,10)
# sum(3,4,5,6)
# sum(223,44,5354,5321,545)


import math
def factorial(x):
    if x== 1:
        return 1
    else:
        return x * math.factorial(x-1)
print(math.factorial(int(input('vvedite chislo = '))))