import math

# b = float(input("Введите число"))
# z1 = math.cos(3/8 * math.pi - b/4 )**2 - math.cos(11/8 * math.pi + b/4 )**2
# z2 = math.sqrt(2)/2 * math.sin(b/2)
# print(z1)
# print(z2)
a = float(input("Введите число"))
z1 = (1 - 2 * math.sin(a)**2) / (1 + math.sin(2*a)**2)
z2 = (1 - math.tan(a))/(1 + math.tan(a))
print(z1)
print(z2)




